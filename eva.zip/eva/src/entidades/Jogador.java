package entidades;

public class Jogador {
    private int id;
    private String nome;
    private int idade;
    private String posicao;
    private Selecao selecao;
    private int selecao_id;
    public Jogador(){};
    public Jogador(String nome, int idade, String posicao, Selecao selecao) {
        this.nome = nome;
        this.idade = idade;
        this.posicao = posicao;
        this.selecao = selecao;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getPosicao() {
        return posicao;
    }

    public void setPosicao(String position) {
        this.posicao = position;
    }

    public Selecao getSelecao() {
        return selecao;
    }

    public void setSelecao(Selecao selecao) {
        this.selecao = selecao;
    }
    public int getSelecao_id() {
        return selecao_id;
    }

    public void setSelecao_id(int selecao_id) {
        this.selecao_id = selecao_id;
    }
}
