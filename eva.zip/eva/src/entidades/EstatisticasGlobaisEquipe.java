package entidades;
public class EstatisticasGlobaisEquipe {
    private int id;
    private int partidaId;
    private int selecaoId;
    private int remates;
    private int livres;
    private int forasDeJogo;

    public EstatisticasGlobaisEquipe() {
    }

    public EstatisticasGlobaisEquipe(int id, int partidaId, int selecaoId, int remates, int livres, int forasDeJogo) {
        this.id = id;
        this.partidaId = partidaId;
        this.selecaoId = selecaoId;
        this.remates = remates;
        this.livres = livres;
        this.forasDeJogo = forasDeJogo;
    }

    public EstatisticasGlobaisEquipe(int partidaId, int selecaoId, int remates, int livres, int forasDeJogo) {
        this.partidaId = partidaId;
        this.selecaoId = selecaoId;
        this.remates = remates;
        this.livres = livres;
        this.forasDeJogo = forasDeJogo;
    }

    // Getters e Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPartidaId() {
        return partidaId;
    }

    public void setPartidaId(int partidaId) {
        this.partidaId = partidaId;
    }

    public int getSelecaoId() {
        return selecaoId;
    }

    public void setSelecaoId(int selecaoId) {
        this.selecaoId = selecaoId;
    }

    public int getRemates() {
        return remates;
    }

    public void setRemates(int remates) {
        this.remates = remates;
    }

    public int getLivres() {
        return livres;
    }

    public void setLivres(int livres) {
        this.livres = livres;
    }

    public int getForasDeJogo() {
        return forasDeJogo;
    }

    public void setForasDeJogo(int forasDeJogo) {
        this.forasDeJogo = forasDeJogo;
    }

    @Override
    public String toString() {
        return "EstatisticasGlobaisEquipe{" +
                "id=" + id +
                ", partidaId=" + partidaId +
                ", selecaoId=" + selecaoId +
                ", remates=" + remates +
                ", livres=" + livres +
                ", forasDeJogo=" + forasDeJogo +
                '}';
    }
}
