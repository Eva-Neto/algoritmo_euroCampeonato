package entidades;

public class EstatisticasPartida {
    private Jogador jogador;
    private int gols;
    private int cartoesAmarelos;
    private int cartoesVermelhos;
    private int remates;
    private int cantos;
    private int forasDeJogo;

    // Construtor
    public EstatisticasPartida(Jogador jogador, int gols, int cartoesAmarelos, int cartoesVermelhos, int remates, int cantos, int forasDeJogo) {
        this.jogador = jogador;
        this.gols = gols;
        this.cartoesAmarelos = cartoesAmarelos;
        this.cartoesVermelhos = cartoesVermelhos;
        this.remates = remates;
        this.cantos = cantos;
        this.forasDeJogo = forasDeJogo;
    }

    // Getters e setters
    public Jogador getPlayer() {
        return jogador;
    }

    public void setPlayer(Jogador jogador) {
        this.jogador = jogador;
    }

    public int getGols() {
        return gols;
    }

    public void setGols(int gols) {
        this.gols = gols;
    }

    public int getCartoesAmarelos() {
        return cartoesAmarelos;
    }

    public void setCartoesAmarelos(int cartoesAmarelos) {
        this.cartoesAmarelos = cartoesAmarelos;
    }

    public int getCartoesVermelhos() {
        return cartoesVermelhos;
    }

    public void setCartoesVermelhos(int cartoesVermelhos) {
        this.cartoesVermelhos = cartoesVermelhos;
    }

    public int getRemates() {
        return remates;
    }

    public void setRemates(int remates) {
        this.remates = remates;
    }

    public int getCantos() {
        return cantos;
    }

    public void setCantos(int cantos) {
        this.cantos = cantos;
    }

    public int getForasDeJogo() {
        return forasDeJogo;
    }

    public void setForasDeJogo(int forasDeJogo) {
        this.forasDeJogo = forasDeJogo;
    }
}
