package entidades;
import java.util.ArrayList;
import java.util.List;

public class Selecao {
    private int id;
    private String nome;
    private Pais pais;
    private int pais_id;
    private List<Jogador> players;

    public Selecao(){};

    public Selecao(int id, String nome) {
        this.id = id;
        this.nome = nome;
        this.pais = pais;
        this.players = new ArrayList<Jogador>();
    }
    public Selecao(int id, String nome, Pais pais) {
        this.id = id;
        this.nome = nome;
        this.pais = pais;
        this.players = new ArrayList<>();
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Pais getCountry() {
        return pais;
    }

    public void setCountry(Pais pais) {
        this.pais = pais;
    }

    public List<Jogador> getPlayers() {
        return players;
    }

    public void setPlayers(List<Jogador> players) {
        this.players = players;
    }

    public int getPais_id() {
        return pais_id;
    }

    public void setPais_id(int pais_id) {
        this.pais_id = pais_id;
    }
}

