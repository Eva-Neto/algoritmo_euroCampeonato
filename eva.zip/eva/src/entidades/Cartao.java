package entidades;

public class Cartao {
}
