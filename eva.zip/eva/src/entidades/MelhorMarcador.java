package entities;

public class MelhorMarcador {
    private int jogadorId;
    private int numGols;

    public MelhorMarcador(int jogadorId, int numGols) {
        this.jogadorId = jogadorId;
        this.numGols = numGols;
    }

    public int getJogadorId() {
        return jogadorId;
    }

    public void setJogadorId(int jogadorId) {
        this.jogadorId = jogadorId;
    }

    public int getNumGols() {
        return numGols;
    }

    public void setNumGols(int numGols) {
        this.numGols = numGols;
    }

    @Override
    public String toString() {
        return "MelhorMarcador{" +
                "jogadorId=" + jogadorId +
                ", numGols=" + numGols +
                '}';
    }
}
