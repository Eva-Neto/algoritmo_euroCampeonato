package entidades;

public class Estadio {
    private int id;
    private String nome;
    private Cidade cidade;
    private int cidade_id;
    private int capacity;

    public Estadio(int id, String nome, Cidade cidade, int capacity) {
        this.id = id;
        this.nome = nome;
        this.cidade = cidade;
        this.capacity = capacity;
    }
    public Estadio() {}

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Cidade getCity() {
        return cidade;
    }

    public void setCity(Cidade cidade) {
        this.cidade = cidade;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public int getCidade_id() {
        return cidade_id;
    }

    public void setCidade_id(int cidade_id) {
        this.cidade_id = cidade_id;
    }
}
