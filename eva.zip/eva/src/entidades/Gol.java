package entidades;
public class Gol extends Evento{
    private int partidaId;
    private Jogador jogador;
    private int minuto;
    public Gol(int partidaId, Jogador jogador, int minuto) {
        super();
        this.partidaId = partidaId;
        this.jogador = jogador;
        this.minuto = minuto;
    }

    public int getPartidaId() {
        return partidaId;
    }

    public void setPartidaId(int partidaId) {
        this.partidaId = partidaId;
    }

    public Jogador getJogador() {
        return jogador;
    }

    public void setJogador(Jogador jogador) {
        this.jogador = jogador;
    }

    public int getMinuto() {
        return minuto;
    }

    public void setMinuto(int minuto) {
        this.minuto = minuto;
    }
}
