package entidades;
import entidades.Classificacao;

import java.util.List;
import java.util.Collections;
import java.util.Comparator;

public class Grupo {
    private int id;
    private String nome;
    private List<Classificacao> selecoes;

    public Grupo() {
    }


    public Grupo(int grupoID , String nome , List<Classificacao> selecoes){
        this.nome = nome;
        this.selecoes = selecoes;
        this.id = grupoID;
    }

    public String getNome() {
        return nome;
    }

    public List<Classificacao> obterClassificacaoFinal() {
        Collections.sort(selecoes, new Comparator<Classificacao>() {
            @Override
            public int compare(Classificacao sg1, Classificacao sg2) {
                if (sg1.getPontos() != sg2.getPontos()) {
                    return sg2.getPontos() - sg1.getPontos();
                }
                // Critérios de desempate: vitórias, saldo de gols, gols marcados
                if (sg1.getVitorias() != sg2.getVitorias()) {
                    return sg2.getVitorias() - sg1.getVitorias();
                }
                int saldoGols1 = sg1.getGolsPro() - sg1.getGolsContra();
                int saldoGols2 = sg2.getGolsPro() - sg2.getGolsContra();
                if (saldoGols1 != saldoGols2) {
                    return saldoGols2 - saldoGols1;
                }
                return sg2.getGolsPro() - sg1.getGolsPro();
            }
        });
        return selecoes;
    }

    public List<Classificacao> getSelecoes() {
        return selecoes;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
