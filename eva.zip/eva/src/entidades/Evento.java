package entidades;
public abstract class Evento {
    protected int id;
    protected int partidaId;
    protected int minuto;

    public Evento(){};
    public Evento(int partidaId, int minuto) {
        this.partidaId = partidaId;
        this.minuto = minuto;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPartidaId() {
        return partidaId;
    }

    public void setPartidaId(int partidaId) {
        this.partidaId = partidaId;
    }

    public int getMinuto() {
        return minuto;
    }

    public void setMinuto(int minuto) {
        this.minuto = minuto;
    }
}
