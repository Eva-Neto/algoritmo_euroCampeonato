import entidades.*;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {
    private EuroCampeonatoDAO dao;
    public Main() {
        this.dao = new EuroCampeonatoDAO();
    }
    public void menu() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        int option = 0;
        while (option != 14) {
            System.out.println("Menu:");
            System.out.println("1. Criar País");
            System.out.println("2. Listar Países");
            System.out.println("3. Criar Cidade");
            System.out.println("4. Listar Cidades");
            System.out.println("5. Criar Estádio");
            System.out.println("6. Listar Estádios");
            System.out.println("7. Criar Seleção");
            System.out.println("8. Listar Seleções");
            System.out.println("9. Criar Jogador");
            System.out.println("10. Listar Jogadores");
            System.out.println("11. Mostrar classificao dos grupos");
            System.out.println("12. Realizar Partida");
            System.out.println("13. Listar uma partida");
            System.out.println("14. Sair");
            System.out.print("Escolha uma opção: ");
            option = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (option) {
                case 1:
                    criarPais(scanner);
                    break;
                case 2:
                    listarPaises();
                    break;
                case 3:
                    criarCidade(scanner);
                    break;
                case 4:
                    listarCidades();
                    break;
                case 5:
                    criarEstadio(scanner);
                    break;
                case 6:
                    listarEstadios();
                    break;
                case 7:
                    criarSelecao(scanner);
                    break;
                case 8:
                    listarSelecoes();
                    break;
                case 9:
                    criarJogador(scanner);
                    break;
                case 10:
                    listarJogadores(scanner);
                    break;
                case 11:
                    obterclassificao();
                    break;
                case 12:
                    realizarPartida(scanner);
                    break;
                case 13:
                    listarPartida(scanner);
                    break;
                case 14:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }

        scanner.close();
    }

    // Métodos para Paises
    private void criarPais(Scanner scanner) {
        System.out.print("Digite o nome do país: ");
        String nome = scanner.nextLine();
        Pais pais = new Pais();
        pais.setNome(nome);
        try {
            dao.createPais(pais);
            System.out.println("País criado com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private void listarPaises() {
        try {
            List<Pais> paises = dao.listAllPaises();
            for (Pais pais : paises) {
                System.out.println("ID:" + pais.getId() + "-" + "Nome: " +pais.getNome());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Métodos para Cidades
    private void criarCidade(Scanner scanner) {
        System.out.print("Digite o nome da cidade: ");
        String nome = scanner.nextLine();
        System.out.print("Digite o ID do país: ");
        int paisId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        Cidade cidade = new Cidade();
        cidade.setNome(nome);
        cidade.setPais_id(paisId);
        try {
            dao.createCidade(cidade);
            System.out.println("Cidade criada com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void listarCidades() {
        try {
            List<Cidade> cidades = dao.listAllCidades();
            for (Cidade cidade : cidades) {
              Pais  pais =  dao.getPaisById(cidade.getPais_id());
              System.out.println("ID: " +cidade.getId()  + " - " + "Nome: " +cidade.getNome()
              + " - " + "Pais: "+pais.getNome());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Métodos para Estadios
    private void criarEstadio(Scanner scanner) {
        System.out.print("Digite o nome do estádio: ");
        String nome = scanner.nextLine();
        System.out.print("Digite o ID da cidade: ");
        int cidadeId = scanner.nextInt();
        System.out.print("Digite a capacidade do estádio: ");
        int capacidade = scanner.nextInt();
        scanner.nextLine(); // consume newline
        Estadio estadio = new Estadio();
        estadio.setNome(nome);
        estadio.setCidade_id(cidadeId);
        estadio.setCapacity(capacidade);
        try {
            dao.createEstadio(estadio);
            System.out.println("Estádio criado com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void listarEstadios() {
        try {
            List<Estadio> estadios = dao.listAllEstadios();
            for (Estadio estadio : estadios) {
                Cidade  cidade =  dao.getCidadeById(estadio.getCidade_id());
                System.out.println("ID: " +estadio.getId()  + " - " + "Nome: " +estadio.getNome()
                        + " - " + "Cidade: "+cidade.getNome());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Métodos para Selecoes
    private void criarSelecao(Scanner scanner) {
        System.out.print("Digite o nome da seleção: ");
        String nome = scanner.nextLine();
        System.out.print("Digite o ID do país: ");
        int paisId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        Selecao selecao = new Selecao();
        selecao.setNome(nome);
        selecao.setPais_id(paisId);
        try {
            dao.createSelecao(selecao);
            System.out.println("Seleção criada com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void listarSelecoes() {
        try {
            List<Selecao> selecoes = dao.listAllSelecoes();
            for (Selecao selecao : selecoes) {
                System.out.println("ID:" + selecao.getNome());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Métodos para Jogadores
    private void criarJogador(Scanner scanner) throws SQLException {
        System.out.print("Digite o nome do jogador: ");
        String nome = scanner.nextLine();
        System.out.print("Digite a idade do jogador: ");
        int idade = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Digite a posição do jogador: ");
        String posicao = scanner.nextLine();
        System.out.print("Digite o ID da seleção: ");
        int selecaoId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        listarSelecoes();

        Selecao selecao = dao.getSelecaoById(selecaoId);
        if(selecao != null){
            Jogador jogador = new Jogador();
            jogador.setNome(nome);
            jogador.setIdade(idade);
            jogador.setPosicao(posicao);
            jogador.setSelecao_id(selecaoId);
            dao.createJogador(jogador);
            System.out.println("Jogador criado com sucesso!");
        }else{
            System.out.println("Selecao não existe");
        }
    }
    private void listarJogadores(Scanner scanner) {
        try {
            System.out.println("Digite o id selecao:");
            int selecao_id = scanner.nextInt();
            Selecao equipa = dao.getSelecaoById(selecao_id);
            if(equipa != null) {
                List<Jogador> jogadores = dao.listAllJogadoresBySelecao(selecao_id);
                for (Jogador jogador : jogadores) {
                    System.out.println("ID: " + jogador.getId() + "  - " + jogador.getNome() + " - " + jogador.getPosicao() + " - " + jogador.getIdade() + " - " + equipa.getNome());
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void obterclassificao() {
        List<Classificacao> classificacoes = dao.obterClassificacaoDosGrupos();

        System.out.println("Classificação dos Grupos:");
        for (Classificacao classificacao : classificacoes) {
            System.out.println("Grupo: " + classificacao.getGrupo().getNome() +
                    ", Selecao: " + classificacao.getSelecao().getNome() +
                    ", Pontos: " + classificacao.getPontos() +
                    ", Jogos: " + classificacao.getJogos() +
                    ", Vitorias: " + classificacao.getVitorias() +
                    ", Empates: " + classificacao.getEmpates() +
                    ", Derrotas: " + classificacao.getDerrotas() +
                    ", Gols Pro: " + classificacao.getGolsPro() +
                    ", Gols Contra: " + classificacao.getGolsContra() +
                    ", Saldo de Gols: " + classificacao.getSaldo_golos());

            System.out.println("========================================");

        }
    }

    private void obterclassificaoGrupo(List<Classificacao> classificacoes) {
        System.out.println("Classificação dos Grupos:");
        for (Classificacao classificacao : classificacoes) {
            System.out.println("Grupo: " + classificacao.getGrupo().getNome() +
                    ", Selecao: " + classificacao.getSelecao().getNome() +
                    ", Pontos: " + classificacao.getPontos() +
                    ", Jogos: " + classificacao.getJogos() +
                    ", Vitorias: " + classificacao.getVitorias() +
                    ", Empates: " + classificacao.getEmpates() +
                    ", Derrotas: " + classificacao.getDerrotas() +
                    ", Gols Pro: " + classificacao.getGolsPro() +
                    ", Gols Contra: " + classificacao.getGolsContra() +
                    ", Saldo de Gols: " + classificacao.getSaldo_golos());

            System.out.println("========================================");

        }
    }
    private void realizarPartida(Scanner scanner) throws SQLException {
        System.out.println("Digite ID grupo: ");
        int grupo_id = scanner.nextInt();
        Grupo grupo  = dao.getGrupoById(grupo_id);
        if(grupo != null){
            List<Classificacao> classificacaos = dao.getClassificacoesByGrupoId(grupo_id);
            obterclassificaoGrupo(classificacaos);
            System.out.println("Seleciona a equipe Casa: ");
            int equipe_casa = scanner.nextInt();

            System.out.println("Seleciona a equipe Fora: ");
            int equipe_fora = scanner.nextInt();

            Selecao selecaoCasa = dao.getSelecaoById(equipe_casa);
            Selecao selecaoFora = dao.getSelecaoById(equipe_fora);

            if (selecaoCasa != selecaoFora) {
                if(selecaoCasa != null && selecaoFora != null){
                    boolean pertenceSelecaoCasa = dao.verificarSelecaoNoGrupo(equipe_casa,grupo_id);
                    boolean pertenceSelecaoFora = dao.verificarSelecaoNoGrupo(equipe_casa,grupo_id);
                    if(pertenceSelecaoCasa && pertenceSelecaoFora){
                        dao.realizarPartida(equipe_casa,equipe_fora,grupo_id);
                    }else{
                        System.out.println("Uma das equipes nao pertence ao grupo");
                    }
                }
            }

        }
    }
    public void listarPartida(Scanner scanner) throws SQLException {

        System.out.println("Digite o id da partida: ");
        int partida_id = scanner.nextInt();
        Partida partida = dao.buscarPartidaPorId(partida_id);
        if(partida != null){
            System.out.println("Partida ID: " + partida.getId());
            System.out.println("Grupo: " + partida.getGrupo().getNome());
            System.out.println("Seleção 1: " + partida.getSelecao1().getNome() + " (" + partida.getGols1() + " gols)");
            System.out.println("Seleção 2: " + partida.getSelecao2().getNome() + " (" + partida.getGols2() + " gols)");
        }else{
            System.out.println("Nao encontrou a partida");
        }
    }


    public static void main(String[] args) throws SQLException {
        Main service = new Main();
        service.menu();
    }
}
