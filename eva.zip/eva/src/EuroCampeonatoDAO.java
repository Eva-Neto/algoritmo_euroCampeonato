import entidades.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class EuroCampeonatoDAO {
    // Conexão com o banco de dados
    private Connection getConnection() throws SQLException {
        db conn = new db();
        return conn.getConnection();
    }
    // Métodos CRUD para a entidade Pais
    public void createPais(Pais pais) throws SQLException {
        String sql = "INSERT INTO paises (nome) VALUES (?)";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, pais.getNome());
            pstmt.executeUpdate();
        }
    }

    public List<Pais> listAllPaises() throws SQLException {
        List<Pais> paises = new ArrayList<>();
        String sql = "SELECT * FROM paises";
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Pais pais = new Pais();
                pais.setId(rs.getInt("id"));
                pais.setNome(rs.getString("nome"));
                paises.add(pais);
            }
        }
        return paises;
    }

    public Pais getPaisById(int id) throws SQLException {
        Pais pais = null;
        String sql = "SELECT * FROM paises WHERE id = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                pais = new Pais();
                pais.setId(rs.getInt("id"));
                pais.setNome(rs.getString("nome"));
            }
        }
        return pais;
    }

    public Grupo getGrupoById(int id) throws SQLException {
        Grupo grupo = null;
        String sql = "SELECT * FROM grupos WHERE id = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                grupo = new Grupo();
                grupo.setId(rs.getInt("id"));
                grupo.setNome(rs.getString("nome"));
            }
        }
        return grupo;
    }

    public Pais getPaisByNome(String nome) throws SQLException {
        Pais pais = null;
        String sql = "SELECT * FROM paises WHERE nome = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nome);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                pais = new Pais();
                pais.setId(rs.getInt("id"));
                pais.setNome(rs.getString("nome"));
            }
        }
        return pais;
    }

    // Métodos CRUD para a entidade Cidade
    public void createCidade(Cidade cidade) throws SQLException {
        String sql = "INSERT INTO cidades (nome, pais_id) VALUES (?, ?)";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, cidade.getNome());
            pstmt.setInt(2, cidade.getPais_id());
            pstmt.executeUpdate();
        }
    }

    public List<Cidade> listAllCidades() throws SQLException {
        List<Cidade> cidades = new ArrayList<>();
        String sql = "SELECT * FROM cidades";
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Cidade cidade = new Cidade();
                cidade.setId(rs.getInt("id"));
                cidade.setNome(rs.getString("nome"));
                cidade.setPais_id(rs.getInt("pais_id"));
                cidades.add(cidade);
            }
        }
        return cidades;
    }

    public Cidade getCidadeById(int id) throws SQLException {
        Cidade cidade = null;
        String sql = "SELECT * FROM cidades WHERE id = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                cidade = new Cidade();
                cidade.setId(rs.getInt("id"));
                cidade.setNome(rs.getString("nome"));
                cidade.setPais_id(rs.getInt("pais_id"));
            }
        }
        return cidade;
    }

    public Cidade getCidadeByNome(String nome) throws SQLException {
        Cidade cidade = null;
        String sql = "SELECT * FROM cidades WHERE nome = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nome);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                cidade = new Cidade();
                cidade.setId(rs.getInt("id"));
                cidade.setNome(rs.getString("nome"));
                cidade.setPais_id(rs.getInt("pais_id"));
            }
        }
        return cidade;
    }

    // Métodos CRUD para a entidade Estadio
    public void createEstadio(Estadio estadio) throws SQLException {
        String sql = "INSERT INTO estadios (nome, cidade_id, capacidade) VALUES (?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, estadio.getNome());
            pstmt.setInt(2, estadio.getCidade_id());
            pstmt.setInt(3, estadio.getCapacity());
            pstmt.executeUpdate();
        }
    }

    public List<Estadio> listAllEstadios() throws SQLException {
        List<Estadio> estadios = new ArrayList<>();
        String sql = "SELECT * FROM estadios";
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Estadio estadio = new Estadio();
                estadio.setId(rs.getInt("id"));
                estadio.setNome(rs.getString("nome"));
                estadio.setCidade_id(rs.getInt("cidade_id"));
                estadio.setCapacity(rs.getInt("capacidade"));
                estadios.add(estadio);
            }
        }
        return estadios;
    }

    public Estadio getEstadioById(int id) throws SQLException {
        Estadio estadio = null;
        String sql = "SELECT * FROM estadios WHERE id = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                estadio = new Estadio();
                estadio.setId(rs.getInt("id"));
                estadio.setNome(rs.getString("nome"));
                estadio.setCidade_id(rs.getInt("cidade_id"));
                estadio.setCapacity(rs.getInt("capacidade"));
            }
        }
        return estadio;
    }

    public Estadio getEstadioByNome(String nome) throws SQLException {
        Estadio estadio = null;
        String sql = "SELECT * FROM estadios WHERE nome = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nome);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                estadio = new Estadio();
                estadio.setId(rs.getInt("id"));
                estadio.setNome(rs.getString("nome"));
                estadio.setCidade_id(rs.getInt("cidade_id"));
                estadio.setCapacity(rs.getInt("capacidade"));
            }
        }
        return estadio;
    }

    // Métodos CRUD para a entidade Selecao
    public void createSelecao(Selecao selecao) throws SQLException {
        String sql = "INSERT INTO selecoes (nome, pais_id) VALUES (?, ?)";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, selecao.getNome());
            pstmt.setInt(2, selecao.getPais_id());
            pstmt.executeUpdate();
        }
    }

    public List<Selecao> listAllSelecoes() throws SQLException {
        List<Selecao> selecoes = new ArrayList<>();
        String sql = "SELECT * FROM selecoes";
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Selecao selecao = new Selecao();
                selecao.setId(rs.getInt("id"));
                selecao.setNome(rs.getString("nome"));
                selecao.setPais_id(rs.getInt("pais_id"));
                selecoes.add(selecao);
            }
        }
        return selecoes;
    }

    public Selecao getSelecaoById(int id) throws SQLException {
        Selecao selecao = null;
        String sql = "SELECT * FROM selecoes WHERE id = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                selecao = new Selecao();
                selecao.setId(rs.getInt("id"));
                selecao.setNome(rs.getString("nome"));
                selecao.setPais_id(rs.getInt("pais_id"));
            }
        }
        return selecao;
    }

    public Selecao getSelecaoByNome(String nome) throws SQLException {
        Selecao selecao = null;
        String sql = "SELECT * FROM selecoes WHERE nome = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nome);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                selecao = new Selecao();
                selecao.setId(rs.getInt("id"));
                selecao.setNome(rs.getString("nome"));
                selecao.setPais_id(rs.getInt("pais_id"));
            }
        }
        return selecao;
    }

    // Métodos CRUD para a entidade Jogador
    public void createJogador(Jogador jogador) throws SQLException {
        String sql = "INSERT INTO jogadores (nome, idade, posicao, selecao_id) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, jogador.getNome());
            pstmt.setInt(2, jogador.getIdade());
            pstmt.setString(3, jogador.getPosicao());
            pstmt.setInt(4, jogador.getSelecao_id());
            pstmt.executeUpdate();
        }
    }

    public List<Jogador> listAllJogadores() throws SQLException {
        List<Jogador> jogadores = new ArrayList<>();
        String sql = "SELECT * FROM jogadores";
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Jogador jogador = new Jogador();
                jogador.setId(rs.getInt("id"));
                jogador.setNome(rs.getString("nome"));
                jogador.setIdade(rs.getInt("idade"));
                jogador.setPosicao(rs.getString("posicao"));
                jogador.setSelecao_id(rs.getInt("selecao_id"));
                jogadores.add(jogador);
            }
        }
        return jogadores;
    }

    public List<Jogador> listAllJogadoresBySelecao(int selecao_id) throws SQLException {
        List<Jogador> jogadores = new ArrayList<>();
        String sql = "SELECT * FROM jogadores WHERE selecao_id = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, selecao_id);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Jogador jogador = new Jogador();
                jogador.setId(rs.getInt("id"));
                jogador.setNome(rs.getString("nome"));
                jogador.setIdade(rs.getInt("idade"));
                jogador.setPosicao(rs.getString("posicao"));
                jogador.setSelecao_id(rs.getInt("selecao_id"));
                jogadores.add(jogador);
            }
        }
        return jogadores;
    }

    public Jogador getJogadorById(int id) throws SQLException {
        Jogador jogador = null;
        String sql = "SELECT * FROM jogadores WHERE id = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                jogador = new Jogador();
                jogador.setId(rs.getInt("id"));
                jogador.setNome(rs.getString("nome"));
                jogador.setIdade(rs.getInt("idade"));
                jogador.setPosicao(rs.getString("posicao"));
                jogador.setSelecao_id(rs.getInt("selecao_id"));
            }
        }
        return jogador;
    }

    public Jogador getJogadorByNome(String nome) throws SQLException {
        Jogador jogador = null;
        String sql = "SELECT * FROM jogadores WHERE nome = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nome);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                jogador = new Jogador();
                jogador.setId(rs.getInt("id"));
                jogador.setNome(rs.getString("nome"));
                jogador.setIdade(rs.getInt("idade"));
                jogador.setPosicao(rs.getString("posicao"));
                jogador.setSelecao_id(rs.getInt("selecao_id"));
            }
        }
        return jogador;
    }

    public List<Classificacao> obterClassificacaoDosGrupos() {
        List<Classificacao> classificacoes = new ArrayList<>();
        String sql = "SELECT " +
                "g.nome AS grupo, " +
                "s.nome AS selecao, " +
                "sg.pontos, " +
                "sg.jogos, " +
                "sg.vitorias, " +
                "sg.empates, " +
                "sg.derrotas, " +
                "sg.gols_pro, " +
                "sg.gols_contra, " +
                "(sg.gols_pro - sg.gols_contra) AS saldo_de_gols " +
                "FROM grupos g " +
                "JOIN selecao_grupo sg ON g.id = sg.grupo_id " +
                "JOIN selecoes s ON sg.selecao_id = s.id " +
                "ORDER BY g.nome, sg.pontos DESC, saldo_de_gols DESC";

        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql) ) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Grupo grupo = new Grupo();
                grupo.setNome(rs.getString("grupo"));

                Selecao selecao = new Selecao();
                selecao.setNome(rs.getString("selecao"));

                Classificacao classificacao = new Classificacao();
                classificacao.setGrupo(grupo);
                classificacao.setSelecao(selecao);
                classificacao.setPontos(rs.getInt("pontos"));
                classificacao.setJogos(rs.getInt("jogos"));
                classificacao.setVitorias(rs.getInt("vitorias"));
                classificacao.setEmpates(rs.getInt("empates"));
                classificacao.setDerrotas(rs.getInt("derrotas"));
                classificacao.setGolsPro(rs.getInt("gols_pro"));
                classificacao.setGolsContra(rs.getInt("gols_contra"));
                classificacao.setSaldo_golos(rs.getInt("saldo_de_gols"));
                classificacoes.add(classificacao);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return classificacoes;
    }


    public void realizarPartida(int selecaoId1, int selecaoId2 , int grupo_id) throws SQLException {
        Random random = new Random();

        // Gerar resultados aleatórios para a partida
        int golsSelecao1 = random.nextInt(5); // Gols da primeira seleção (0 a 4)
        int golsSelecao2 = random.nextInt(5); // Gols da segunda seleção (0 a 4)

        // Atualizar estatísticas das seleções
        atualizarEstatisticasSelecao(selecaoId1, selecaoId2, golsSelecao1, golsSelecao2);

        // Atualizar estatísticas dos jogadores

        // Registrar a partida na base de dados
        int estadio_id = 1;
        int partida_id = registrarPartida(selecaoId1, selecaoId2, golsSelecao1, golsSelecao2 , grupo_id ,estadio_id );
        atualizarEstatisticasJogadores(selecaoId1, golsSelecao1 , partida_id);
        atualizarEstatisticasJogadores(selecaoId2, golsSelecao2 , partida_id);
    }

    private void atualizarEstatisticasSelecao(int selecaoId1, int selecaoId2, int golsSelecao1, int golsSelecao2) throws SQLException {
        // Atualizar estatísticas da primeira seleção
        String sql = "UPDATE selecao_grupo SET jogos = jogos + 1, gols_pro = gols_pro + ?, gols_contra = gols_contra + ? WHERE selecao_id = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, golsSelecao1);
            pstmt.setInt(2, golsSelecao2);
            pstmt.setInt(3, selecaoId1);
            pstmt.executeUpdate();
        }

        // Atualizar estatísticas da segunda seleção
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, golsSelecao2);
            pstmt.setInt(2, golsSelecao1);
            pstmt.setInt(3, selecaoId2);
            pstmt.executeUpdate();
        }

        // Atualizar pontos, vitórias, empates e derrotas
        if (golsSelecao1 > golsSelecao2) {
            // Selecao1 venceu
            atualizarResultadoSelecao(selecaoId1, 3, 1, 0, 0); // 3 pontos, 1 vitória
            atualizarResultadoSelecao(selecaoId2, 0, 0, 0, 1); // 0 pontos, 1 derrota
        } else if (golsSelecao1 < golsSelecao2) {
            // Selecao2 venceu
            atualizarResultadoSelecao(selecaoId1, 0, 0, 0, 1); // 0 pontos, 1 derrota
            atualizarResultadoSelecao(selecaoId2, 3, 1, 0, 0); // 3 pontos, 1 vitória
        } else {
            // Empate
            atualizarResultadoSelecao(selecaoId1, 1, 0, 1, 0); // 1 ponto, 1 empate
            atualizarResultadoSelecao(selecaoId2, 1, 0, 1, 0); // 1 ponto, 1 empate
        }
    }

    private void atualizarResultadoSelecao(int selecaoId, int pontos, int vitorias, int empates, int derrotas) throws SQLException {
        String sql = "UPDATE selecao_grupo SET pontos = pontos + ?, vitorias = vitorias + ?, empates = empates + ?, derrotas = derrotas + ? WHERE selecao_id = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, pontos);
            pstmt.setInt(2, vitorias);
            pstmt.setInt(3, empates);
            pstmt.setInt(4, derrotas);
            pstmt.setInt(5, selecaoId);
            pstmt.executeUpdate();
        }
    }

    private void atualizarEstatisticasJogadores(int selecaoId, int partidaId, int golsMarcados) throws SQLException {
        List<Jogador> jogadores = listAllJogadoresBySelecao(selecaoId);
        Random random = new Random();

        // Distribuir os gols de forma aleatória entre os jogadores
        for (int i = 0; i < golsMarcados; i++) {
            int jogadorIndex = random.nextInt(jogadores.size());
            Jogador jogador = jogadores.get(jogadorIndex);

            // Atualizar a tabela de estatísticas individuais
            String sqlEstatisticas = "INSERT INTO estatisticas_individuais (partida_id, jogador_id, golos) VALUES (?, ?, ?) "
                    + "ON CONFLICT (partida_id, jogador_id) DO UPDATE SET golos = estatisticas_individuais.golos + 1";
            try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sqlEstatisticas)) {
                pstmt.setInt(1, partidaId);
                pstmt.setInt(2, jogador.getId());
                pstmt.setInt(3, 1); // Incrementar gols
                pstmt.executeUpdate();
            }
        }
    }


    private int registrarPartida(int selecaoCasaId, int selecaoForaId, int golsSelecaoCasa, int golsSelecaoFora, int grupoId, int estadioId) throws SQLException {
        String sql = "INSERT INTO partidas (gols_selecao1, gols_selecao2, selecao_casa_id, selecao_fora_id, grupo_id, estadio_id, data_hora) VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, golsSelecaoCasa);
            pstmt.setInt(2, golsSelecaoFora);
            pstmt.setInt(3, selecaoCasaId);
            pstmt.setInt(4, selecaoForaId);
            pstmt.setInt(5, grupoId);
            pstmt.setInt(6, estadioId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Partida realizada com sucesso");
                return rs.getInt(1);
            } else {
                throw new SQLException("Falha ao inserir a partida, nenhum ID retornado.");
            }
        }
    }



    public boolean verificarSelecaoNoGrupo(int selecaoId, int grupoId) throws SQLException {
        String sql = "SELECT COUNT(*) AS count FROM selecao_grupo WHERE selecao_id = ? AND grupo_id = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, selecaoId);
            pstmt.setInt(2, grupoId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                int count = rs.getInt("count");
                return count > 0;
            }
        }
        return false;
    }

    public Partida buscarPartidaPorId(int partidaId) throws SQLException {
        String sql = "SELECT " +
                "p.id AS partida_id, " +
                "g.id AS grupo_id, " +
                "g.nome AS grupo_nome, " +
                "s1.id AS selecao1_id, " +
                "s1.nome AS selecao1_nome, " +
                "p.gols_selecao1 AS gols1, " +
                "s2.id AS selecao2_id, " +
                "s2.nome AS selecao2_nome, " +
                "p.gols_selecao2 AS gols2 " +
                "FROM partidas p " +
                "JOIN grupos g ON p.grupo_id = g.id " +
                "JOIN selecoes s1 ON p.selecao_casa_id = s1.id " +
                "JOIN selecoes s2 ON p.selecao_fora_id = s2.id " +
                "WHERE p.id = ?";

        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, partidaId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Partida partida = new Partida();
                partida.setId(rs.getInt("partida_id"));

                Grupo grupo = new Grupo();
                grupo.setId(rs.getInt("grupo_id"));
                grupo.setNome(rs.getString("grupo_nome"));
                partida.setGrupo(grupo);

                Selecao selecao1 = new Selecao();
                selecao1.setId(rs.getInt("selecao1_id"));
                selecao1.setNome(rs.getString("selecao1_nome"));
                partida.setSelecao1(selecao1);
                partida.setGols1(rs.getInt("gols1"));

                Selecao selecao2 = new Selecao();
                selecao2.setId(rs.getInt("selecao2_id"));
                selecao2.setNome(rs.getString("selecao2_nome"));
                partida.setSelecao2(selecao2);
                partida.setGols2(rs.getInt("gols2"));

                return partida;
            }
        }
        return null; // Retornar null caso a partida não seja encontrada
    }
    public Partida mostraPartida(int partidaId) throws SQLException {
        String sql = "SELECT " +
                "p.id AS partida_id, " +
                "g.id AS grupo_id, " +
                "g.nome AS grupo_nome, " +
                "s1.id AS selecao1_id, " +
                "s1.nome AS selecao1_nome, " +
                "p.gols_selecao1 AS gols1, " +
                "s2.id AS selecao2_id, " +
                "s2.nome AS selecao2_nome, " +
                "p.gols_selecao2 AS gols2 " +
                "FROM partidas p " +
                "JOIN grupos g ON p.grupo_id = g.id " +
                "JOIN selecoes s1 ON p.selecao1_id = s1.id " +
                "JOIN selecoes s2 ON p.selecao2_id = s2.id " +
                "WHERE p.id = ?";

        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, partidaId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Partida partida = new Partida();
                partida.setId(rs.getInt("partida_id"));

                Grupo grupo = new Grupo();
                grupo.setId(rs.getInt("grupo_id"));
                grupo.setNome(rs.getString("grupo_nome"));
                partida.setGrupo(grupo);

                Selecao selecao1 = new Selecao();
                selecao1.setId(rs.getInt("selecao1_id"));
                selecao1.setNome(rs.getString("selecao1_nome"));
                partida.setSelecao1(selecao1);
                partida.setGols1(rs.getInt("gols1"));

                Selecao selecao2 = new Selecao();
                selecao2.setId(rs.getInt("selecao2_id"));
                selecao2.setNome(rs.getString("selecao2_nome"));
                partida.setSelecao2(selecao2);
                partida.setGols2(rs.getInt("gols2"));

                return partida;
            }
        }
        return null; // Retornar null caso a partida não seja encontrada
    }


    public List<Classificacao> getClassificacoesByGrupoId(int grupoId) throws SQLException {
        List<Classificacao> classificacoes = new ArrayList<>();
        String sql = "SELECT " +
                "cg.id, " +
                "cg.grupo_id, " +
                "s.id AS selecao_id, " +
                "s.nome AS selecao_nome, " +
                "g.id AS grupo_id, " +
                "g.nome AS grupo_nome, " +
                "cg.pontos, " +
                "cg.jogos, " +
                "cg.vitorias, " +
                "cg.empates, " +
                "cg.derrotas, " +
                "cg.gols_pro, " +
                "cg.gols_contra " +
                "FROM selecao_grupo cg " +
                "JOIN selecoes s ON cg.selecao_id = s.id " +
                "JOIN grupos g ON cg.grupo_id = g.id " +
                "WHERE cg.grupo_id = ?";

        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, grupoId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Classificacao classificacao = new Classificacao();
                classificacao.setId(rs.getInt("id"));
                classificacao.setGrupoId(rs.getInt("grupo_id"));

                Selecao selecao = new Selecao();
                selecao.setId(rs.getInt("selecao_id"));
                selecao.setNome(rs.getString("selecao_nome"));
                classificacao.setSelecao(selecao);

                Grupo grupo = new Grupo();
                grupo.setId(rs.getInt("grupo_id"));
                grupo.setNome(rs.getString("grupo_nome"));
                classificacao.setGrupo(grupo);

                classificacao.setPontos(rs.getInt("pontos"));
                classificacao.setJogos(rs.getInt("jogos"));
                classificacao.setVitorias(rs.getInt("vitorias"));
                classificacao.setEmpates(rs.getInt("empates"));
                classificacao.setDerrotas(rs.getInt("derrotas"));
                classificacao.setGolsPro(rs.getInt("gols_pro"));
                classificacao.setGolsContra(rs.getInt("gols_contra"));

                classificacoes.add(classificacao);
            }
        }

        return classificacoes;
    }



}
