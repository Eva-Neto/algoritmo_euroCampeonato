import java.sql.*;

public class db {
    private Connection connection;
    String url = "jdbc:postgresql://localhost:5432/eva?user=postgres&password=12345678";
    public db() throws SQLException {
        try {
            Class.forName("org.postgresql.Driver");
            this.connection = DriverManager.getConnection(url);
        } catch (SQLException | ClassNotFoundException e) {
            throw new SQLException("Erro ao conectar ao banco de dados", e);
        }
    }

    public Connection getConnection() {
        return connection;
    }
    public void close() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }
}
